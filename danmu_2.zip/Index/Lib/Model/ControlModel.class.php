<?php
	class ControlModel extends Model{
		
	}