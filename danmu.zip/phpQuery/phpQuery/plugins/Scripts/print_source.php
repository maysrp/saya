<?php
/**
 * Script outputs document markup and changes HTML special chars to entities.
 *
 * @author Tobiasz Cudnik <tobiasz.cudnik/gmail.com>
 */
/** @var phpQueryObject */
$self = $self;
$return = htmlspecialchars($self);