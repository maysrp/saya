<?php
	$dir=dirname(__FILE__);
	define('APP_PATH','./Index/');
	define('APP_NAME','Index');
	define('APP_DEBUG',True);
	define("DIR",$dir);
	require './ThinkPHP/ThinkPHP.php';
?>